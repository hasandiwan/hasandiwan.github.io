module QuizHelper
  def memory_wait
    case self.level
    when 0
      5.seconds
    when 1 
      25.seconds
    when 2
      2.minutes
    when 3
      10.minutes
    when 4
      1.hour
    when 5
      5.hours
    when 6
      1.day
    when 7
      5.days
    when 8
      25.days
    when 9
      4.months
    else
      nil
    end
  end
end
