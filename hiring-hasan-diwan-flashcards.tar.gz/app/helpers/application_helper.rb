module ApplicationHelper
   module BooleanRefinements
      refine FalseClass do
        def to_i
          0
        end
      end

      refine TrueClass do
        def to_i
          1
        end
      end
   end
end
