class ExaminationController < ApplicationController
  def index
  end

  def question 
  end

  def answer
    question_id = params[:question_id].to_i
    question_obj = Question.find(question_id)
    is_correct = params[:answer].eql?(question_obj.answer)
    if is_correct then
      Current.level = question_obj.level+1)
      question_obj.next+=1.day
    else
      Current.level = question_obj.level-1)
      question_obj.next+=1.hour
    end

    q = question_obj.save!
  end
end
