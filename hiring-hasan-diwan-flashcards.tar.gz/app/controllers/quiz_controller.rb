class QuizController < ApplicationController
end
