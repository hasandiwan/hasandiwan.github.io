class Question < ApplicationRecord
  belongs_to :subject
  def adjust_next
    if params[:is_correct] then
      self.next += self.next.to_i hours 
    else
      self.next -= self.next.to_i hours
    end
  end
end
