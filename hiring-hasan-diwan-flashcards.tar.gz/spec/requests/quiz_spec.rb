require 'rails_helper'

RSpec.describe "Quizzes", type: :request do
  describe "PATCH /quiz/1/questions/1" do
    let(:answer) { FactoryBot.build(:question).answer }
    let(:next_showing) { FactoryBot.build(:question).next }
    it 'updates next on correct answer' do
      current_next = next_showing
      patch "/quiz/1/questions/1", params: {guess: answer } 
      assert FactoryBot.build(:question).next.to_i > current_next
    end
    it 'updates next on incorrect answer' do
      current_next = next_showing
      patch "/quiz/1/questions/1", params: {guess: "#{answer}!" }
      assert FactoryBot.build(:question).next.to_i < current_next
    end

  end
end
