require 'rails_helper'

RSpec.describe RegistrationsController, type: :request do
  describe 'GET #new' do
    it 'responds successfully' do
      get sign_up_url
      expect(response).to be_successful
    end
  end

  describe 'POST #create' do
    it 'creates a new user and redirects to root url' do
      expect {
        post sign_up_url, params: {
          email: 'lazaronixon@hey.com',
          password: 'Secret1*3*5*',
          password_confirmation: 'Secret1*3*5*'
        }
      }.to change(User, :count).by(1)

      expect(response).to redirect_to(root_url)
    end
  end
end
