require 'rails_helper'

RSpec.describe PasswordsController, type: :request do
  before do
    @user = sign_in_as(users(:lazaro_nixon))
  end

  describe 'GET #edit' do
    it 'responds successfully' do
      get edit_password_url
      expect(response).to be_successful
    end
  end

  describe 'PATCH #update' do
    context 'with valid parameters' do
      it 'redirects to root url' do
        patch password_url, params: {
          password_challenge: 'Secret1*3*5*',
          password: 'Secret6*4*2*',
          password_confirmation: 'Secret6*4*2*'
        }
        expect(response).to redirect_to(root_url)
      end
    end

    context 'with invalid password challenge' do
      it 'renders unprocessable entity and shows error' do
        patch password_url, params: {
          password_challenge: 'SecretWrong1*3',
          password: 'Secret6*4*2*',
          password_confirmation: 'Secret6*4*2*'
        }
        expect(response).to have_http_status(:unprocessable_entity)
        expect(response.body).to include('Password challenge is invalid')
      end
    end
  end
end
