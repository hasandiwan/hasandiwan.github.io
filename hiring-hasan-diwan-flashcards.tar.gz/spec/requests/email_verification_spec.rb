require "rails_helper"

RSpec.describe EmailVerificationsController, type: :request do
  let(:user) { users(:lazaro_nixon) }

  before do
    sign_in_as(user)
    user.update!(verified: false)
  end

  describe "POST #create" do
    it "sends a verification email and redirects to the root" do
      expect do
        post identity_email_verification_url
      end.to have_enqueued_mail(UserMailer, :email_verification).with(params: { user: user })

      expect(response).to redirect_to(root_url)
    end
  end

  describe "GET #show" do
    context "with a valid token" do
      it "verifies the user's email and redirects to the root" do
        sid = user.generate_token_for(:email_verification)

        get identity_email_verification_url(sid: sid, email: user.email)

        expect(response).to redirect_to(root_url)
        expect(user.reload.verified?).to be(true)
      end
    end

    context "with an expired token" do
      it "does not verify the email, redirects, and sets an alert" do
        sid = user.generate_token_for(:email_verification)

        travel 3.days do
          get identity_email_verification_url(sid: sid, email: user.email)
        end

        expect(user.reload.verified?).to be(false)
        expect(response).to redirect_to(edit_identity_email_url)
        expect(flash[:alert]).to eq("That email verification link is invalid")
      end
    end
  end
end
