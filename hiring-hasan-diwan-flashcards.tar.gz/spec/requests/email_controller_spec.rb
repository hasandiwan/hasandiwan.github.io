require "rails_helper"

RSpec.describe "EmailsController", type: :request do
  let(:user) { users(:lazaro_nixon) }
  let(:password) { "Secret1*3*5*" } # Assuming this is the correct password from fixtures

  before do
    sign_in_as(user)
  end

  describe "GET /edit" do
    it "returns a successful response" do
      get edit_identity_email_url
      expect(response).to be_successful
    end
  end

  describe "PATCH /update" do
    context "with a valid password challenge" do
      it "updates the email and redirects to the root URL" do
        patch identity_email_url, params: { email: "new_email@hey.com", password_challenge: password }
        
        # In a real-world scenario, this might update a separate `unconfirmed_email` attribute.
        # This test just verifies the redirect, matching the original test's behavior.
        expect(response).to redirect_to(root_url)
      end
    end

    context "with an invalid password challenge" do
      it "does not update the email and returns an unprocessable entity status" do
        patch identity_email_url, params: { email: "new_email@hey.com", password_challenge: "WrongPassword" }

        expect(response).to have_http_status(:unprocessable_entity)
        expect(response.body).to include("Password challenge is invalid")
      end
    end
  end
end
