require 'rails_helper'

RSpec.describe SessionsController, type: :request do
  before do
    @user = users(:lazaro_nixon)
  end

  describe 'GET #index' do
    it 'responds successfully' do
      sign_in_as(@user)

      get sessions_url
      expect(response).to be_successful
    end
  end

  describe 'GET #new' do
    it 'responds successfully' do
      get sign_in_url
      expect(response).to be_successful
    end
  end

  describe 'POST #create (sign in)' do
    it 'redirects to root url upon successful sign in' do
      post sign_in_url, params: { email: @user.email, password: 'Secret1*3*5*' }
      expect(response).to redirect_to(root_url)

      follow_redirect!
      expect(response).to be_successful
    end
  end

  describe 'POST #create with invalid credentials' do
    it 'redirects to sign_in_url with an alert message' do
      post sign_in_url, params: { email: @user.email, password: 'SecretWrong1*3' }
      expect(response).to redirect_to(sign_in_url(email_hint: @user.email))

      follow_redirect!
      expect(flash[:alert]).to eq('That email or password is incorrect')

      get root_url
      expect(response).to redirect_to(sign_in_url)
    end
  end

  describe 'DELETE #destroy (sign out)' do
    it 'signs out the user and redirects to sign_in_url' do
      sign_in_as(@user)

      delete session_url(@user.sessions.last)
      expect(response).to redirect_to(sessions_url)

      follow_redirect!
      expect(response).to redirect_to(sign_in_url)
    end
  end
end
