require 'rails_helper'

RSpec.describe "quizzes/edit", type: :view do
  let(:quiz) {
    Quiz.create!(
      question: "MyString",
      quiz_id: nil,
      answer: "MyString",
      level: 1
    )
  }

  before(:each) do
    assign(:quiz, quiz)
  end

  it "renders the edit quiz form" do
    render

    assert_select "form[action=?][method=?]", quiz_path(quiz), "post" do

      assert_select "input[name=?]", "quiz[question]"

      assert_select "input[name=?]", "quiz[quiz_id_id]"

      assert_select "input[name=?]", "quiz[answer]"

      assert_select "input[name=?]", "quiz[level]"
    end
  end
end
