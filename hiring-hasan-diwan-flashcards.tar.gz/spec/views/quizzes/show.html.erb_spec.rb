require 'rails_helper'

RSpec.describe "quizzes/show", type: :view do
  before(:each) do
    assign(:quiz, Quiz.create!(
      question: "Question",
      quiz_id: nil,
      answer: "Answer",
      level: 2
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Question/)
    expect(rendered).to match(//)
    expect(rendered).to match(/Answer/)
    expect(rendered).to match(/2/)
  end
end
