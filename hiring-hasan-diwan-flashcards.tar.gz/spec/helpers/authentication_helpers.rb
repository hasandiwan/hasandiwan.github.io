module AuthenticationHelpers
  def sign_in(user)
    # Simulate the session creation as authentication-zero would
    session[:user_id] = user.id
  end

  def sign_out
    session[:user_id] = nil
  end
end

RSpec.configure do |config|
  config.include AuthenticationHelpers, type: :controller # For controller specs
  config.include AuthenticationHelpers, type: :request    # For request specs
  config.include AuthenticationHelpers, type: :system     # For system specs
end

