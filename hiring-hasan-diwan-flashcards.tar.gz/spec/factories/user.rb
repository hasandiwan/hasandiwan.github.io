FactoryBot.define do
  factory :user do
    # Common attributes with dynamic data
    email { Faker::Internet.email }
    # Assume your User model handles hashing the password on save
    password { "Secret1*3*5*" }

    # Define a trait for the verified status
    trait :verified do
      verified { true }
    end

    # Define another trait for unverified users
    trait :unverified do
      verified { false }
    end

    # Define a specific user instance, if needed
    factory :lazaro_nixon do
      email { "lazaronixon@hotmail.com" }
      verified { true }
    end
  end
end
