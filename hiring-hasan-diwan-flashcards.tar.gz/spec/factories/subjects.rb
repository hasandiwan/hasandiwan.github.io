FactoryBot.define do
  factory :subject do
    topic { "Eurovision" }
    description { "MyString" }
  end
end
