FactoryBot.define do
  factory :question do
    question { "Who sang the song ``Volare'' at Eurovision in 1989?" }
    answer { "Gipsy Kings" }
  end
end
