class CreateSubjects < ActiveRecord::Migration[8.0]
  def change
    create_table :subjects do |t|
      t.references :users, null: false, foreign_key: true
      t.string :topic
      t.string :description

      t.timestamps
    end
  end
end
