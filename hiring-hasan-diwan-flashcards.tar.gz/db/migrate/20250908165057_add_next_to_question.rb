class AddNextToQuestion < ActiveRecord::Migration[8.0]
  def change
    add_column :questions, :next, :datetime, default: nil
    drop_table :quiz
  end
end
